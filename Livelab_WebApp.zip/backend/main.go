//This Go program connects to OCI Cache and OCI Database with PostgreSQL and exposes their data as consumable APIs
//In addition it connects to 3rd party real-time information stream also exposes it as an API and updates the cache.
//Created by Piotr Kurzynoga @ Oracle Czech Republic
//Copyright (c) 2026, Oracle and/or its affiliates.
//Licensed under the Universal Permissive License v1.0 as shown at https://oss.oracle.com/licenses/upl.

package main

import (
	"context"
	"crypto/tls"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"reflect"
	"strconv"
	"strings"
	"time"

	"github.com/go-redis/redis/v8"
	"github.com/gorilla/mux"
	_ "github.com/jackc/pgx/v5/stdlib"
	"github.com/oracle/oci-go-sdk/v65/common"
	"github.com/oracle/oci-go-sdk/v65/common/auth"
	"github.com/oracle/oci-go-sdk/v65/secrets"
	"github.com/rs/cors"
)

// Model for stops
type Stop struct {
	StopID    string  `json:"stop_id"`
	StopName  string  `json:"stop_name"`
	Latitude  float64 `json:"latitude"`
	Longitude float64 `json:"longitude"`
}

// Model for route
type Route struct {
	RouteShortName string `json:"route_short_name"`
	RouteLongName  string `json:"route_long_name"`
	RouteURL       string `json:"route_url"`
}

// Model for routes
type Routes struct {
	RTRoute struct {
		GTFSTripID         string `json:"gtfs_trip_id"`
		RouteType          string `json:"route_type"`
		GTFSRouteShortName string `json:"gtfs_route_short_name"`
	} `json:"properties"`
}

type RoutesCollection struct {
	RTRoute []Routes `json:"features"`
}

// Model for trips
type Trip struct {
	StopID        string `json:"stop_id"`
	ArrivalTime   string `json:"arrival_time"`
	DepartureTime string `json:"departure_time"`
}

// Model for realtime trip
type TripData struct {
	Longitude       float64 `json:"longitude"`
	Latitude        float64 `json:"latitude"`
	TripID          string  `json:"trip_id"`
	StartTimestamp  string  `json:"start_timestamp"`
	OriginTimestamp string  `json:"origin_timestamp"`

	LastStopID        *string `json:"last_stop_id,omitempty"`
	LastStopArrival   *string `json:"last_stop_arrival,omitempty"`
	LastStopDeparture *string `json:"last_stop_departure,omitempty"`

	NextStopID        *string `json:"next_stop_id,omitempty"`
	NextStopArrival   *string `json:"next_stop_arrival,omitempty"`
	NextStopDeparture *string `json:"next_stop_departure,omitempty"`
}

// Raw Model for realtime trip
type rawTrip struct {
	Geometry struct {
		Coordinates []float64 `json:"coordinates"` // [lon, lat]
	} `json:"geometry"`
	Properties struct {
		LastPosition struct {
			OriginTimestamp string `json:"origin_timestamp"`
			LastStop        *struct {
				ID            string `json:"id"`
				ArrivalTime   string `json:"arrival_time"`
				DepartureTime string `json:"departure_time"`
			} `json:"last_stop"`
			NextStop *struct {
				ID            string `json:"id"`
				ArrivalTime   string `json:"arrival_time"`
				DepartureTime string `json:"departure_time"`
			} `json:"next_stop"`
		} `json:"last_position"`
		Trip struct {
			StartTimestamp string `json:"start_timestamp"`
			GTFS           struct {
				TripID string `json:"trip_id"`
			} `json:"gtfs"`
		} `json:"trip"`
	} `json:"properties"`
}

// OCI Auth
var configProvider common.ConfigurationProvider

// OCI Regions
var current_region = "eu-frankfurt-1"
var primary_region = "eu-frankfurt-1"

// PostgreSQL Secret OCID
var primary_secretOCID = "database_secret_ocid"

// Database connection
var psql *sql.DB
var redisClient *redis.Client

var postgreSQL = map[string]string{
	"user":     "admin",
	"database": "postgres",
	"password": "",
	"host":     "your_postgresql_host",
	"port":     "5432",
	"sslmode":  "require",
}

var redis_host = "your_cache_host:6379"

// PID Realtime Information
var api_key = "transport_api_key"

func PostgresConnection(dbParams map[string]string) *sql.DB {
	dsn := fmt.Sprintf(
		"user=%s password=%s host=%s port=%s dbname=%s sslmode=%s",
		dbParams["user"],
		dbParams["password"],
		dbParams["host"],
		dbParams["port"],
		dbParams["database"],
		dbParams["sslmode"],
	)
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		panic(fmt.Errorf("error in sql.Open: %w", err))
	}
	err = db.Ping()
	if err != nil {
		panic(fmt.Errorf("error pinging db: %w", err))
	}
	return db
}

func init() {
	//Check if secrets are configured
	if primary_secretOCID == "" {
		fmt.Println("primary secret variable not set")
		os.Exit(1)
	}

	//Configure instance principal authentication
	var err error
	configProvider, err = auth.InstancePrincipalConfigurationProvider()
	if err != nil {
		log.Fatalf("Failed to get instance principal provider: %v", err)
	}

	//Check current region
	var secretValue = ""
	current_region, err = GetRegion()

	if current_region == primary_region {
		secretValue, err = GetSecretValueFromVault(primary_secretOCID)
		if err != nil {
			fmt.Printf("Error retrieving secret: %v\n", err)
			os.Exit(1)
		}
	} else {
		log.Fatalf("The instance is not in the correct region.")
	}

	postgreSQL["password"] = secretValue
	fmt.Println("Postgres password set using Secret.")

	psql = PostgresConnection(postgreSQL)
	fmt.Println("Postgres DB Connection Started")

	// Connect to Redis
	redisClient = redis.NewClient(&redis.Options{
		Addr:     redis_host,
		Password: "", // No password set for this example
		DB:       0,  // Use default database
		TLSConfig: &tls.Config{
			ServerName: "aaaeicj2tiayu4q5lq7u7qg6lrdriao3see3p2db22w3e5vyj5fascq-p.redis.eu-frankfurt-1.oci.oraclecloud.com",
		},
	})
	if err := redisClient.Ping(context.Background()).Err(); err != nil {
		log.Fatalf("Error connecting to Redis: %v", err)
	}
	fmt.Println("Valkey Connection Started")
}

func main() {
	router := mux.NewRouter()

	// User API Endpoints
	router.HandleFunc("/stop/{stop_id}", getStop).Methods("GET", "OPTIONS")
	router.HandleFunc("/trip/{trip_id}", getTrip).Methods("GET", "OPTIONS")
	router.HandleFunc("/rt_trip/{trip_id}", getRTrip).Methods("GET", "OPTIONS")
	router.HandleFunc("/routes", getRoutes).Methods("GET", "OPTIONS")
	router.HandleFunc("/rt_routes", getRTRoutes).Methods("GET", "OPTIONS")

	// Allow CORS for any origins
	handler := cors.New(cors.Options{
		//AllowedOrigins: []string{"http://localhost:3000"}, (Optional to confine to local env)
		AllowedHeaders:   ([]string{"Access-Control-Allow-Headers", "Origin", "Accept", "X-Requested-With", "Content-Type", "Access-Control-Request-Method", "Access-Control-Request-Headers"}),
		AllowedOrigins:   ([]string{"*"}),
		AllowedMethods:   ([]string{"GET", "POST", "OPTIONS", "DELETE", "PUT"}),
		AllowCredentials: true,
		Debug:            false,
	}).Handler(router)

	fmt.Printf("Server listening on port 8585\n")
	log.Fatal(http.ListenAndServe(":8585", handler))
}

// GetStopbyID GET /stops/{stop_id}    (((DB + Cache Only)))
func getStop(w http.ResponseWriter, r *http.Request) {
	start := time.Now() //Measure the time

	var stop Stop

	stopID := mux.Vars(r)["stop_id"]
	if stopID == "" {
		http.Error(w, "Missing stop_id in URL", http.StatusBadRequest)
		return
	}

	cacheKey := "stop:" + stopID

	//Attempt to get from cache
	cached, err := redisClient.Get(context.Background(), cacheKey).Result()
	if err == nil {
		// Cache hit
		var stop Stop
		if err := json.Unmarshal([]byte(cached), &stop); err == nil {
			log.Printf("[CACHE] stop_id=%s time=%s", stopID, time.Since(start)) //Time after Cache
			json.NewEncoder(w).Encode(stop)
			return
		}
	} else if err != redis.Nil {
		handleError("redis get", err)
	}

	// Query the database
	row := psql.QueryRow("SELECT stop_id, stop_name, latitude, longitude FROM public_transport.stops WHERE stop_id = $1", stopID)
	err = row.Scan(&stop.StopID, &stop.StopName, &stop.Latitude, &stop.Longitude)

	if err == sql.ErrNoRows {
		http.Error(w, "Stop not found", http.StatusNotFound)
		return
	} else if err != nil {
		handleError("query row", err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	//Cache the result
	jsonBytes, err := json.Marshal(stop)
	if err == nil {
		redisClient.Set(context.Background(), cacheKey, jsonBytes, 5*time.Minute) // Expiry after 5 minutes.
	}

	log.Printf("[DB] stop_id=%s time=%s", stopID, time.Since(start)) //Time after DB

	json.NewEncoder(w).Encode(stop)
}

// GetTripbyID GET /trip/{trip_id}   (((DB + Cache Only)))
func getTrip(w http.ResponseWriter, r *http.Request) {
	start := time.Now() //Measure the time

	var trips []Trip

	tripID := mux.Vars(r)["trip_id"]
	if tripID == "" {
		http.Error(w, "Missing trip_id in URL", http.StatusBadRequest)
		return
	}

	cacheKey := "trip:" + tripID

	//Attempt to get from cache
	cached, err := redisClient.Get(context.Background(), cacheKey).Result()
	if err == nil {
		// Cache hit
		if err := json.Unmarshal([]byte(cached), &trips); err == nil {
			log.Printf("[CACHE] trip_id=%s time=%s", tripID, time.Since(start)) //Time after Cache
			json.NewEncoder(w).Encode(trips)
			return
		}
	} else if err != redis.Nil {
		handleError("redis get", err)
	}

	// Query the database
	row, err := psql.Query("SELECT arrival_time, departure_time, stop_id FROM public_transport.stop_times WHERE trip_id = $1", tripID)
	for row.Next() {
		var trip Trip
		err = row.Scan(&trip.ArrivalTime, &trip.DepartureTime, &trip.StopID)

		trips = append(trips, trip)
	}

	if err == sql.ErrNoRows {
		http.Error(w, "Trip not found", http.StatusNotFound)
		return
	} else if err != nil {
		handleError("query row", err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	//Cache the result
	jsonBytes, err := json.Marshal(trips)
	if err == nil {
		redisClient.Set(context.Background(), cacheKey, jsonBytes, 5*time.Minute) // Expiry after 5 minutes.
	}

	log.Printf("[DB] trip_id=%s time=%s", tripID, time.Since(start)) //Time after DB

	json.NewEncoder(w).Encode(trips)
}

// GetRTripbyID GET /rt_trip/{trip_id}   (((Cache Only)))
func getRTrip(w http.ResponseWriter, r *http.Request) {
	start := time.Now() //Measure the time

	var trip TripData
	var raw rawTrip

	tripID := mux.Vars(r)["trip_id"]
	if tripID == "" {
		http.Error(w, "Missing trip_id in URL", http.StatusBadRequest)
		return
	}

	cacheKey := "rt_trip:" + tripID

	//Attempt to get from cache
	cached, err := redisClient.Get(context.Background(), cacheKey).Result()
	if err == nil {
		// Cache hit
		if err := json.Unmarshal([]byte(cached), &trip); err == nil {
			log.Printf("[CACHE] rt_trip_id=%s time=%s", tripID, time.Since(start)) //Time after Cache
			json.NewEncoder(w).Encode(trip)
			return
		}
	} else if err != redis.Nil {
		handleError("redis get", err)
	}

	rt_trip_url := fmt.Sprintf("https://api.golemio.cz/v2/vehiclepositions/%s?includeNotTracking=false&includePositions=false&preferredTimezone=Europe_Prague", tripID)

	req, err := http.NewRequest("GET", rt_trip_url, nil)
	if err != nil {
		http.Error(w, "Failed to create request", http.StatusInternalServerError)
		return
	}

	req.Header.Set("X-Access-Token", api_key)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		http.Error(w, "Failed to fetch data", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	if err := json.NewDecoder(resp.Body).Decode(&raw); err != nil {
		http.Error(w, "Failed to decode response", http.StatusInternalServerError)
		return
	}

	trip = TripData{
		Longitude:       raw.Geometry.Coordinates[0],
		Latitude:        raw.Geometry.Coordinates[1],
		TripID:          raw.Properties.Trip.GTFS.TripID,
		StartTimestamp:  raw.Properties.Trip.StartTimestamp,
		OriginTimestamp: raw.Properties.LastPosition.OriginTimestamp,
	}

	if raw.Properties.LastPosition.LastStop != nil {
		trip.LastStopID = &raw.Properties.LastPosition.LastStop.ID
		trip.LastStopArrival = &raw.Properties.LastPosition.LastStop.ArrivalTime
		trip.LastStopDeparture = &raw.Properties.LastPosition.LastStop.DepartureTime
	}
	if raw.Properties.LastPosition.NextStop != nil {
		trip.NextStopID = &raw.Properties.LastPosition.NextStop.ID
		trip.NextStopArrival = &raw.Properties.LastPosition.NextStop.ArrivalTime
		trip.NextStopDeparture = &raw.Properties.LastPosition.NextStop.DepartureTime
	}

	//Cache the result
	jsonBytes, err := json.Marshal(trip)
	if err == nil {
		redisClient.Set(context.Background(), cacheKey, jsonBytes, 5*time.Second) // Expiry after 20 seconds balance between performance and latest information also limiting API calls.
	}

	log.Printf("[API] rt_trip_id=%s time=%s", tripID, time.Since(start)) //Time after API Request

	json.NewEncoder(w).Encode(trip)
}

// getRTRoutes GET /rt_routes   (((Cache Only)))  -- Returns the list of current trip IDs for a list of routes
func getRTRoutes(w http.ResponseWriter, r *http.Request) {
	start := time.Now() //Measure the time

	//Routes model
	var routes RoutesCollection

	//Fixed routes, concatenated for API Call
	lines := []int{9, 11, 14}
	api_prep := make([]string, len(lines))
	for i, r := range lines {
		api_prep[i] = "routeShortName=" + strconv.Itoa(r)
	}
	queryString := strings.Join(api_prep, "&")

	cacheKey := "rt_routes:2"

	//Attempt to get from cache
	cached, err := redisClient.Get(context.Background(), cacheKey).Result()
	if err == nil {
		// Cache hit
		if err := json.Unmarshal([]byte(cached), &routes); err == nil {
			log.Printf("[CACHE] lines=%s time=%s", lines, time.Since(start)) //Time after Cache
			json.NewEncoder(w).Encode(routes)
			return
		}
	} else if err != redis.Nil {
		handleError("redis get", err)
	}

	rt_routes_url := fmt.Sprintf("https://api.golemio.cz/v2/public/vehiclepositions?%s", queryString)
	log.Println(rt_routes_url)

	req, err := http.NewRequest("GET", rt_routes_url, nil)
	if err != nil {
		http.Error(w, "Failed to create request", http.StatusInternalServerError)
		return
	}

	req.Header.Set("X-Access-Token", api_key)

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		http.Error(w, "Failed to fetch data", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	// raw, err := io.ReadAll(resp.Body)
	// if err != nil {
	// 	log.Fatal(err)
	// }
	// log.Println(string(raw))

	if err := json.NewDecoder(resp.Body).Decode(&routes); err != nil {
		http.Error(w, "Failed to decode response", http.StatusInternalServerError)
		return
	}

	type RouteOutput struct {
		GTFSTripID         string `json:"gtfs_trip_id"`
		RouteType          string `json:"route_type"`
		GTFSRouteShortName string `json:"gtfs_route_short_name"`
	}

	var routeoutput []RouteOutput
	for _, r := range routes.RTRoute {
		routeoutput = append(routeoutput, RouteOutput{
			GTFSTripID:         r.RTRoute.GTFSTripID,
			RouteType:          r.RTRoute.RouteType,
			GTFSRouteShortName: r.RTRoute.GTFSRouteShortName,
		})
	}

	//Cache the result
	jsonBytes, err := json.Marshal(routeoutput)
	if err == nil {
		redisClient.Set(context.Background(), cacheKey, jsonBytes, 20*time.Second) // Expiry after 1 minute balance between performance and latest information also limiting API calls.
	}

	log.Printf("[API] lines=%s time=%s", lines, time.Since(start)) //Time after API Request

	json.NewEncoder(w).Encode(routeoutput)
}

// GetRoutes GET /routes  (((DB + Cache Only)))
func getRoutes(w http.ResponseWriter, r *http.Request) {
	start := time.Now() //Measure the time

	var routes []Route

	cacheKey := "routes:1"

	//Attempt to get from cache
	cached, err := redisClient.Get(context.Background(), cacheKey).Result()
	if err == nil {
		// Cache hit
		if err := json.Unmarshal([]byte(cached), &routes); err == nil {
			log.Printf("[CACHE] time=%s", time.Since(start)) //Time after Cache
			json.NewEncoder(w).Encode(routes)
			return
		}
	} else if err != redis.Nil {
		handleError("redis get", err)
	}

	// Query the database
	row, err := psql.Query("SELECT route_short_name, route_long_name, route_url FROM public_transport.routes where route_id < 36")
	for row.Next() {
		var route Route
		err = row.Scan(&route.RouteShortName, &route.RouteLongName, &route.RouteURL)
		routes = append(routes, route)
	}

	if err == sql.ErrNoRows {
		http.Error(w, "Stop not found", http.StatusNotFound)
		return
	} else if err != nil {
		handleError("query row", err)
		http.Error(w, "Internal server error", http.StatusInternalServerError)
		return
	}

	//Cache the result
	jsonBytes, err := json.Marshal(routes)
	if err == nil {
		redisClient.Set(context.Background(), cacheKey, jsonBytes, 5*time.Minute) // Expiry after 5 minutes.
	}

	log.Printf("[DB] time=%s", time.Since(start)) //Time after DB

	json.NewEncoder(w).Encode(routes)
}

// Error handling function.
func handleError(msg string, err error) {
	if err != nil {
		fmt.Println(msg, err)
		//os.Exit(1)
	}
}

// EncodeFloats takes a struct and returns a map where float64 fields are converted to string
func EncodeFloats(v interface{}) (map[string]string, error) {
	result := make(map[string]string)

	// Use reflection to iterate over struct fields
	val := reflect.ValueOf(v)
	if val.Kind() == reflect.Ptr {
		val = val.Elem()
	}

	// Make sure we're working with a struct
	if val.Kind() != reflect.Struct {
		return nil, fmt.Errorf("expected a struct, but got %T", v)
	}

	// Iterate through the struct fields
	for i := 0; i < val.NumField(); i++ {
		field := val.Field(i)
		fieldType := val.Type().Field(i)
		fieldName := fieldType.Name

		// Only encode float64 fields
		if field.Kind() == reflect.Float64 {
			// Convert float64 to string and add to result map
			result[fieldName] = strconv.FormatFloat(field.Float(), 'f', 6, 64)
		}
	}

	return result, nil
}

// Return the current OCI Region for Instance Principal
func GetRegion() (string, error) {
	//Using instance principal
	current_region, err := configProvider.Region()
	if err != nil {
		return "", fmt.Errorf("error getting region: %w", err)
	}
	fmt.Printf("Currently in Region: %s\n", current_region)

	return current_region, nil
}

// GetSecretValueFromVault retrieves a secret from OCI Vault using API key-based authentication
func GetSecretValueFromVault(secretOCID string) (string, error) {
	// Create a SecretsClient
	client, err := secrets.NewSecretsClientWithConfigurationProvider(configProvider)
	if err != nil {
		return "", fmt.Errorf("error creating secrets client: %w", err)
	}

	// Prepare GetSecretBundle request
	request := secrets.GetSecretBundleRequest{
		SecretId: &secretOCID,
	}

	// Make the API call
	response, err := client.GetSecretBundle(context.Background(), request)
	if err != nil {
		return "", fmt.Errorf("error getting secret bundle: %w", err)
	}

	// Extract and decode the base64 content
	contentDetails, ok := response.SecretBundle.SecretBundleContent.(secrets.Base64SecretBundleContentDetails)
	if !ok {
		return "", fmt.Errorf("unexpected content format")
	}

	decoded, err := base64.StdEncoding.DecodeString(*contentDetails.Content)
	if err != nil {
		return "", fmt.Errorf("error decoding base64 secret: %w", err)
	}

	return string(decoded), nil
}
